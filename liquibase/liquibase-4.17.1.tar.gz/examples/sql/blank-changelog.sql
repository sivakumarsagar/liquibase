--liquibase formatted sql
/* https://docs.liquibase.com/concepts/changelogs/sql-format.html */

--changeset authorname:1
/* Insert SQL change objects here */


--changeset authorname:2
/* Insert SQL change objects here */



